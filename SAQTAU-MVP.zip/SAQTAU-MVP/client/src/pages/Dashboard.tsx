import { useCurrentUser } from "@/hooks/use-user";
import { useActivities } from "@/hooks/use-activities";
import { Link, Redirect } from "wouter";
import { Scan, Trophy, ArrowUpRight, Globe, History } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { CardHover } from "@/components/ui/card-hover";

function ActivityItem({ activity }: { activity: any }) {
  const isPositive = activity.pointsChange > 0;
  
  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-green-50 mb-3 last:mb-0">
      <div className="flex items-center gap-4">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
          isPositive ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"
        }`}>
          {isPositive ? <Globe className="w-5 h-5" /> : <History className="w-5 h-5" />}
        </div>
        <div>
          <p className="font-semibold text-foreground capitalize">{activity.type} Scan</p>
          <p className="text-xs text-muted-foreground">
            {format(new Date(activity.timestamp), "MMM d, h:mm a")}
          </p>
        </div>
      </div>
      <span className={`font-bold ${isPositive ? "text-green-600" : "text-red-500"}`}>
        {isPositive ? "+" : ""}{activity.pointsChange} pts
      </span>
    </div>
  );
}

export default function Dashboard() {
  const { data: user, isLoading, userId } = useCurrentUser();
  const { data: activities } = useActivities(user?.id);

  if (!userId) return <Redirect to="/" />;
  if (isLoading) return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"/></div>;
  if (!user) return <Redirect to="/onboarding" />;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header / Stats */}
      <div className="bg-primary pt-12 pb-24 px-6 rounded-b-[2.5rem] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        
        <div className="relative z-10 max-w-md mx-auto">
          <div className="flex justify-between items-center mb-8">
            <div className="flex items-center gap-4">
              <img src="/images/logo.jpg" alt="Saqtau Logo" className="w-12 h-12 rounded-xl bg-white p-1" />
              <div>
                <p className="text-green-100 text-sm font-medium mb-0.5">Welcome,</p>
                <h1 className="text-2xl font-display font-bold text-white">{user.name}</h1>
              </div>
            </div>
            <div className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-medium text-white border border-white/20">
              {user.district} District
            </div>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-xl shadow-green-900/10 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground font-medium mb-1">Total Balance</p>
              <h2 className="text-4xl font-display font-bold text-foreground">{user.points} <span className="text-lg text-primary">pts</span></h2>
            </div>
            <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center shadow-lg shadow-accent/30 animate-pulse">
              <Trophy className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 -mt-12 max-w-md mx-auto space-y-8">
        {/* Main Action */}
        <Link href="/scan">
          <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-3xl p-1 shadow-lg shadow-black/5 group"
          >
            <div className="bg-foreground text-white rounded-[1.3rem] p-4 flex items-center justify-between group-hover:bg-foreground/95 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                  <Scan className="w-6 h-6 text-accent" />
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-lg">Scan QR Code</h3>
                  <p className="text-sm text-gray-400">At a Smart Bin or Partner</p>
                </div>
              </div>
              <ArrowUpRight className="w-6 h-6 text-accent" />
            </div>
          </motion.button>
        </Link>

        {/* Active Challenge */}
        <div>
          <h3 className="font-display font-bold text-lg mb-4 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-accent" />
            Weekly Challenge
          </h3>
          <CardHover className="p-5 bg-gradient-to-br from-green-50 to-white border-green-100">
            <div className="flex justify-between items-start mb-2">
              <h4 className="font-bold text-foreground">Glass Master</h4>
              <span className="text-xs font-bold bg-green-200 text-green-800 px-2 py-1 rounded-lg">Active</span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">Recycle 5 glass bottles this week to earn a bonus badge.</p>
            <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
              <div className="h-full bg-accent w-[40%]" />
            </div>
            <p className="text-xs text-right mt-2 font-medium text-muted-foreground">2/5 bottles</p>
          </CardHover>
        </div>

        {/* Recent Activity */}
        <div>
          <h3 className="font-display font-bold text-lg mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {activities && activities.length > 0 ? (
              activities.slice(0, 5).map(act => <ActivityItem key={act.id} activity={act} />)
            ) : (
              <div className="text-center py-8 text-muted-foreground bg-white rounded-2xl border border-dashed">
                <p>No scans yet. Start recycling!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
