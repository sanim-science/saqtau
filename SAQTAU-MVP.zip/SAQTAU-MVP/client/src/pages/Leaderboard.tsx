import { useLeaderboard, useCurrentUser } from "@/hooks/use-user";
import { Redirect } from "wouter";
import { Trophy, Medal, User } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Leaderboard() {
  const { userId } = useCurrentUser();
  const { data: leaders, isLoading } = useLeaderboard();

  if (!userId) return <Redirect to="/" />;

  const topThree = leaders?.slice(0, 3) || [];
  const rest = leaders?.slice(3) || [];

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-primary pt-12 pb-20 px-6 rounded-b-[2.5rem] text-center text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
        <h1 className="text-3xl font-display font-bold relative z-10">Leaderboard</h1>
        <p className="text-green-100 relative z-10">Top recyclers in Almaty</p>
      </div>

      {/* Podium */}
      <div className="px-6 -mt-12 mb-8 relative z-10">
        <div className="flex justify-center items-end gap-2">
          {/* Second Place */}
          {topThree[1] && (
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 rounded-full border-4 border-gray-300 bg-white flex items-center justify-center overflow-hidden mb-2 relative">
                <span className="text-2xl font-bold text-gray-400">2</span>
              </div>
              <div className="bg-white/80 backdrop-blur-sm p-3 rounded-t-2xl w-24 text-center shadow-sm">
                <p className="font-bold text-sm truncate">{topThree[1].name}</p>
                <p className="text-xs text-primary font-bold">{topThree[1].points} pts</p>
              </div>
            </div>
          )}

          {/* First Place */}
          {topThree[0] && (
            <div className="flex flex-col items-center -mb-4 z-10">
              <div className="relative">
                <Trophy className="w-8 h-8 text-yellow-400 absolute -top-10 left-1/2 -translate-x-1/2 animate-bounce" />
                <div className="w-20 h-20 rounded-full border-4 border-yellow-400 bg-white flex items-center justify-center overflow-hidden mb-2">
                  <span className="text-3xl font-bold text-yellow-500">1</span>
                </div>
              </div>
              <div className="bg-white p-4 rounded-t-2xl w-28 text-center shadow-lg border-t-4 border-yellow-400">
                <p className="font-bold text-foreground truncate">{topThree[0].name}</p>
                <p className="text-sm text-primary font-bold">{topThree[0].points} pts</p>
              </div>
            </div>
          )}

          {/* Third Place */}
          {topThree[2] && (
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 rounded-full border-4 border-amber-600 bg-white flex items-center justify-center overflow-hidden mb-2">
                <span className="text-2xl font-bold text-amber-700">3</span>
              </div>
              <div className="bg-white/80 backdrop-blur-sm p-3 rounded-t-2xl w-24 text-center shadow-sm">
                <p className="font-bold text-sm truncate">{topThree[2].name}</p>
                <p className="text-xs text-primary font-bold">{topThree[2].points} pts</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* List */}
      <div className="px-6 max-w-md mx-auto space-y-3">
        {isLoading ? (
          <div className="text-center py-8">Loading rankings...</div>
        ) : (
          rest.map((user, idx) => (
            <div 
              key={user.id} 
              className={cn(
                "flex items-center gap-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm",
                String(user.id) === String(userId) && "border-primary ring-1 ring-primary bg-green-50"
              )}
            >
              <div className="font-display font-bold text-lg text-muted-foreground w-6 text-center">
                {idx + 4}
              </div>
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-gray-500" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-foreground">{user.name}</h3>
                <p className="text-xs text-muted-foreground">{user.district}</p>
              </div>
              <div className="font-bold text-primary">
                {user.points} pts
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
