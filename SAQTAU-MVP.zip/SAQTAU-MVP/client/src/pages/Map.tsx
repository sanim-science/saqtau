import { useLocations } from "@/hooks/use-locations";
import { useCurrentUser } from "@/hooks/use-user";
import { Redirect } from "wouter";
import { MapPin, Navigation as NavIcon, Search } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";

export default function MapPage() {
  const { userId } = useCurrentUser();
  const { data: locations, isLoading } = useLocations();
  const [search, setSearch] = useState("");

  if (!userId) return <Redirect to="/" />;

  const filteredLocations = locations?.filter(loc => 
    loc.name.toLowerCase().includes(search.toLowerCase()) || 
    loc.address.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background pb-24 flex flex-col h-screen">
      {/* Map Header */}
      <div className="bg-white p-4 shadow-sm z-10">
        <h1 className="text-2xl font-display font-bold mb-4">Recycle Points</h1>
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search nearby bins..." 
            className="pl-10 rounded-xl bg-gray-50 border-gray-100"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Map View Placeholder */}
      <div className="flex-1 bg-gray-100 relative overflow-hidden">
        {/* Static Map Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-90 shadow-inner"
          style={{ backgroundImage: `url('/images/almaty-map.jpg')` }} 
        >
          <div className="absolute inset-0 bg-black/10" />
        </div>

        {/* Floating Pins */}
        {locations?.slice(0, 5).map((loc, i) => (
          <div 
            key={loc.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group cursor-pointer"
            style={{ 
              top: `${40 + (i * 10)}%`, 
              left: `${30 + (i * 15)}%` 
            }}
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-transform group-hover:scale-110 ${
              loc.type === 'smart_bin' ? 'bg-primary text-white' : 'bg-blue-500 text-white'
            }`}>
              <MapPin className="w-5 h-5 fill-current" />
            </div>
            <div className="mt-1 px-2 py-1 bg-white rounded-md shadow-md text-[10px] font-bold opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
              {loc.name}
            </div>
          </div>
        ))}
      </div>

      {/* Location List Sheet */}
      <div className="bg-white rounded-t-3xl shadow-[0_-5px_20px_rgba(0,0,0,0.05)] -mt-6 relative z-10 flex flex-col max-h-[40vh]">
        <div className="p-4 border-b flex items-center justify-center">
          <div className="w-12 h-1.5 bg-gray-200 rounded-full" />
        </div>
        
        <div className="overflow-y-auto p-4 space-y-4">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading locations...</div>
          ) : filteredLocations?.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No locations found.</div>
          ) : (
            filteredLocations?.map(loc => (
              <div key={loc.id} className="flex items-start gap-4 p-4 rounded-2xl bg-gray-50 border border-gray-100 hover:border-primary/30 transition-colors">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  loc.type === 'smart_bin' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                }`}>
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-foreground">{loc.name}</h3>
                  <p className="text-sm text-muted-foreground mt-0.5">{loc.address}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide ${
                      loc.type === 'smart_bin' ? 'bg-green-200 text-green-800' : 'bg-blue-200 text-blue-800'
                    }`}>
                      {loc.type.replace('_', ' ')}
                    </span>
                    <span className="text-[10px] text-gray-400">• 0.8 km away</span>
                  </div>
                </div>
                <button className="p-2 rounded-full bg-white shadow-sm border border-gray-100 text-primary hover:bg-primary hover:text-white transition-colors">
                  <NavIcon className="w-5 h-5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
