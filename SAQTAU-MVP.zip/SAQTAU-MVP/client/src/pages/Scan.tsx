import { useCurrentUser } from "@/hooks/use-user";
import { useProcessScan } from "@/hooks/use-scan";
import { Redirect, useLocation } from "wouter";
import { Loader2, ArrowLeft, CheckCircle, XCircle, AlertTriangle, Camera, RefreshCw } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { BrowserQRCodeReader } from '@zxing/library';

export default function Scan() {
  const { data: user, userId } = useCurrentUser();
  const processScan = useProcessScan();
  const [, setLocation] = useLocation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasCamera, setHasCamera] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState<{
    success: boolean;
    pointsEarned: number;
    message: string;
    newBalance: number;
    wasteType: 'plastic' | 'glass' | 'wrong';
  } | null>(null);
  const [showPenaltyDialog, setShowPenaltyDialog] = useState(false);

  useEffect(() => {
    const codeReader = new BrowserQRCodeReader();
    let controls: any;

    async function startScanner() {
      try {
        const videoInputDevices = await codeReader.listVideoInputDevices();
        if (videoInputDevices.length > 0) {
          setHasCamera(true);
          setIsScanning(true);
          // Prefer back camera if available
          const deviceId = videoInputDevices.find(d => d.label.toLowerCase().includes('back'))?.deviceId || videoInputDevices[0].deviceId;
          
          controls = await codeReader.decodeFromVideoDevice(deviceId, videoRef.current!, (result, err) => {
            if (result) {
              console.log('QR Code detected:', result.getText());
              // Auto-process based on QR text content
              const text = result.getText().toLowerCase();
              if (text.includes('glass')) handleScan('glass');
              else if (text.includes('wrong')) handleScan('wrong');
              else handleScan('plastic');
            }
          });
        } else {
          setHasCamera(false);
          console.warn('No video input devices found');
        }
      } catch (err) {
        console.error('Camera error:', err);
        setHasCamera(false);
      }
    }

    // Delay start slightly to ensure video element is mounted
    const timer = setTimeout(startScanner, 500);

    return () => {
      clearTimeout(timer);
      if (controls) {
        if (typeof controls.stop === 'function') {
          controls.stop();
        } else if (controls.then) {
          controls.then((c: any) => c.stop());
        }
      }
      setIsScanning(false);
    };
  }, []);

  if (!userId) return <Redirect to="/" />;

  const handleScan = async (type: 'plastic' | 'glass' | 'wrong') => {
    if (processScan.isPending) return;
    try {
      const res = await processScan.mutateAsync({
        userId: user!.id,
        wasteType: type
      });
      
      setResult({ ...res, wasteType: type });
      
      if (!res.success && type === 'wrong') {
        setShowPenaltyDialog(true);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const resetScan = () => {
    setResult(null);
    setShowPenaltyDialog(false);
  };

  return (
    <div className="min-h-screen bg-black text-white relative flex flex-col">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 p-6 z-20 flex justify-between items-center">
        <button onClick={() => setLocation("/dashboard")} className="p-2 rounded-full bg-black/40 backdrop-blur-md">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <span className="font-medium bg-black/40 backdrop-blur-md px-3 py-1 rounded-full flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${hasCamera ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'}`} />
          {hasCamera ? 'Live Camera' : 'Simulator Mode'}
        </span>
      </div>

      {/* Camera Viewport */}
      <div className="flex-1 relative overflow-hidden bg-gray-900 flex items-center justify-center">
        {hasCamera ? (
          <video 
            ref={videoRef} 
            className="absolute inset-0 w-full h-full object-cover"
            playsInline
          />
        ) : (
          <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1550989460-0adf9ea622e2?q=80&w=1000&auto=format&fit=crop')] bg-cover bg-center" />
        )}
        
        {/* Scanning Frame Overlay */}
        <div className="absolute inset-0 flex items-center justify-center p-10 pointer-events-none">
          <div className="w-64 h-64 border-2 border-white/30 rounded-3xl relative">
            <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary rounded-tl-xl -mt-1 -ml-1" />
            <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary rounded-tr-xl -mt-1 -mr-1" />
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary rounded-bl-xl -mb-1 -ml-1" />
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary rounded-br-xl -mb-1 -mr-1" />
            
            <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-red-500/80 shadow-[0_0_12px_rgba(239,68,68,0.9)] animate-[scan_2s_ease-in-out_infinite]" />
          </div>
        </div>

        {/* Instructions */}
        <div className="absolute bottom-32 left-0 right-0 text-center px-6">
          <p className="text-white/90 bg-black/60 backdrop-blur-md inline-block px-5 py-2.5 rounded-xl border border-white/10 text-sm font-medium">
            {hasCamera ? 'Point at a QR code to scan automatically' : 'Simulator: Choose waste type below'}
          </p>
        </div>
      </div>

      {/* Controls Area */}
      <div className="bg-white text-foreground p-6 rounded-t-[2.5rem] -mt-8 relative z-10 shadow-[0_-10px_40px_rgba(0,0,0,0.2)]">
        <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-6" />
        <h3 className="font-bold text-center text-lg mb-6">Select Waste Type</h3>
        
        <div className="grid grid-cols-3 gap-4 pb-4">
          <button 
            className="group relative flex flex-col items-center gap-3 p-4 rounded-2xl bg-green-50 border-2 border-green-100 hover:border-green-500 hover:bg-green-100/50 active:scale-95 transition-all duration-200 disabled:opacity-50"
            onClick={() => handleScan('plastic')}
            disabled={processScan.isPending}
          >
            <div className="w-14 h-14 rounded-2xl bg-white shadow-md flex items-center justify-center text-green-600 group-hover:shadow-lg transition-all">
              <span className="text-2xl font-black">P</span>
            </div>
            <span className="text-sm font-bold text-green-800">Plastic</span>
            {processScan.isPending && <Loader2 className="absolute top-2 right-2 w-4 h-4 animate-spin text-green-600" />}
          </button>

          <button 
            className="group relative flex flex-col items-center gap-3 p-4 rounded-2xl bg-blue-50 border-2 border-blue-100 hover:border-blue-500 hover:bg-blue-100/50 active:scale-95 transition-all duration-200 disabled:opacity-50"
            onClick={() => handleScan('glass')}
            disabled={processScan.isPending}
          >
            <div className="w-14 h-14 rounded-2xl bg-white shadow-md flex items-center justify-center text-blue-600 group-hover:shadow-lg transition-all">
              <span className="text-2xl font-black">G</span>
            </div>
            <span className="text-sm font-bold text-blue-800">Glass</span>
          </button>

          <button 
            className="group relative flex flex-col items-center gap-3 p-4 rounded-2xl bg-red-50 border-2 border-red-100 hover:border-red-500 hover:bg-red-100/50 active:scale-95 transition-all duration-200 disabled:opacity-50"
            onClick={() => handleScan('wrong')}
            disabled={processScan.isPending}
          >
            <div className="w-14 h-14 rounded-2xl bg-white shadow-md flex items-center justify-center text-red-600 group-hover:shadow-lg transition-all">
              <span className="text-2xl font-black">X</span>
            </div>
            <span className="text-sm font-bold text-red-800">Wrong</span>
          </button>
        </div>
      </div>

      {/* Success/Failure Overlay */}
      <AnimatePresence>
        {result && result.success && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-green-500 flex flex-col items-center justify-center p-8 text-white text-center"
          >
            <motion.div 
              initial={{ scale: 0 }} 
              animate={{ scale: 1 }} 
              transition={{ type: "spring", delay: 0.2 }}
              className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-6"
            >
              <CheckCircle className="w-12 h-12 text-green-500" />
            </motion.div>
            <h2 className="text-4xl font-bold mb-2">+{result.pointsEarned} Points!</h2>
            <p className="text-green-100 text-lg mb-8">{result.message}</p>
            <Button onClick={resetScan} className="bg-white text-green-600 hover:bg-white/90 rounded-full px-8">
              Scan Another
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Wrong Item Dialog */}
      <Dialog open={showPenaltyDialog} onOpenChange={setShowPenaltyDialog}>
        <DialogContent className="sm:max-w-md bg-white border-0 shadow-2xl rounded-3xl">
          <DialogHeader className="items-center text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <DialogTitle className="text-2xl font-bold text-red-600">
              {result?.pointsEarned && result.pointsEarned < 0 ? "Penalty Applied" : "Incorrect Item"}
            </DialogTitle>
            <DialogDescription className="text-base text-gray-600 pt-2">
              {result?.message}
            </DialogDescription>
          </DialogHeader>
          <div className="bg-gray-50 p-4 rounded-xl text-sm text-gray-500 border border-gray-100 mt-2">
            <strong>Tip:</strong> Ensure containers are empty and rinsed before recycling.
          </div>
          <DialogFooter className="mt-4">
            <Button onClick={resetScan} className="w-full bg-red-600 hover:bg-red-700 text-white rounded-xl py-6">
              I Understand
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
