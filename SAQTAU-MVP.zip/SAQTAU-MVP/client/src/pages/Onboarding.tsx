import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertUserSchema } from "@shared/schema";
import { useCreateUser } from "@/hooks/use-user";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

const DISTRICTS = [
  "Almalinsky",
  "Medeu",
  "Bostandyk",
  "Auezov",
  "Nauryzbay",
  "Turksib",
  "Jetysu",
  "Alatau"
];

const formSchema = insertUserSchema.extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  district: z.string().min(1, "Please select a district"),
});

export default function Onboarding() {
  const createUser = useCreateUser();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      district: "",
    },
  });

  function onSubmit(data: z.infer<typeof formSchema>) {
    createUser.mutate(data);
  }

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center items-center p-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-32 bg-primary/10 rounded-b-[50%] scale-150" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md z-10"
      >
        <div className="text-center mb-8">
          <div className="w-24 h-24 mx-auto mb-4 drop-shadow-md">
            <img src="/images/logo.jpg" alt="Saqtau Logo" className="w-full h-full object-contain rounded-2xl" />
          </div>
          <h1 className="text-3xl font-display font-bold text-foreground">Welcome to Saqtau</h1>
          <p className="text-muted-foreground mt-2">Let's set up your profile to start tracking your eco-impact.</p>
        </div>

        <div className="glass-panel p-8 rounded-3xl">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="John Doe" 
                        {...field} 
                        className="h-12 rounded-xl bg-white border-green-100 focus:border-primary focus:ring-primary/20"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="district"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Select District</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-12 rounded-xl bg-white border-green-100 focus:border-primary focus:ring-primary/20">
                          <SelectValue placeholder="Where do you live?" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-white border-green-200 shadow-xl min-w-[200px] z-[100]">
                        {DISTRICTS.map((district) => (
                          <SelectItem 
                            key={district} 
                            value={district}
                            className="focus:bg-primary/10 focus:text-primary py-3 cursor-pointer border-b border-gray-50 last:border-0"
                          >
                            <span className="font-medium text-gray-900">{district}</span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                className="w-full h-12 text-lg rounded-xl shadow-lg shadow-primary/25 hover:shadow-primary/40" 
                disabled={createUser.isPending}
              >
                {createUser.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Profile...
                  </>
                ) : (
                  "Start Journey"
                )}
              </Button>
            </form>
          </Form>
        </div>
      </motion.div>
    </div>
  );
}
