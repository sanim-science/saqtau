import { Link } from "wouter";
import { ArrowRight, Recycle, MapPin, Globe, Leaf } from "lucide-react";
import { motion } from "framer-motion";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-green-50 flex flex-col items-center overflow-hidden relative">
      {/* Background Decorative Blobs */}
      <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-primary/10 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[400px] h-[400px] bg-accent/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }} />

      {/* Main Content */}
      <div className="relative z-10 w-full max-w-4xl px-6 py-12 md:py-24 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="mb-8">
            <img src="/images/logo.jpg" alt="Saqtau Logo" className="w-24 h-24 mx-auto rounded-2xl drop-shadow-lg" />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-foreground leading-[1.1] mb-6">
            Make Almaty <span className="text-primary">Cleaner</span>,<br />
            One Scan at a Time.
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Join thousands of citizens transforming waste into rewards. Find smart bins, scan your recycling, and earn points for a greener city.
          </p>

          <Link href="/onboarding">
            <button className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-bold text-white transition-all duration-200 bg-primary rounded-full hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg shadow-primary/30 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-1">
              Start Your Journey
              <ArrowRight className="w-5 h-5 ml-2 transition-transform duration-200 group-hover:translate-x-1" />
            </button>
          </Link>
        </motion.div>

        {/* Features Grid */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-24 w-full"
        >
          {[
            {
              icon: Recycle,
              title: "Scan & Earn",
              desc: "Recycle plastic and glass at smart points to earn instant rewards."
            },
            {
              icon: MapPin,
              title: "Find Spots",
              desc: "Locate the nearest smart bins and partner locations on our map."
            },
            {
              icon: Globe,
              title: "Eco Impact",
              desc: "Track your personal contribution to a cleaner environment."
            }
          ].map((feature, i) => (
            <div key={i} className="flex flex-col items-center p-6 bg-white/60 backdrop-blur-sm rounded-3xl border border-white/50 shadow-sm hover:shadow-md transition-all">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-green-100 to-green-50 flex items-center justify-center mb-4 text-primary shadow-inner">
                <feature.icon className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.desc}</p>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Hero Image Illustration */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="w-full h-64 md:h-96 relative mt-auto bg-cover bg-center"
      >
        {/* Scenic mountain landscape - Almaty concept */}
        <img 
          src="https://images.unsplash.com/photo-1541890289-b86df5b6dd26?w=1920&h=800&fit=crop"
          alt="Clean Nature"
          className="w-full h-full object-cover object-bottom opacity-90 mask-image-b"
          style={{ maskImage: 'linear-gradient(to top, black, transparent)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
      </motion.div>
    </div>
  );
}
