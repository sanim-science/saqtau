import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useProcessScan() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: { userId: number; wasteType: 'plastic' | 'glass' | 'wrong' }) => {
      const res = await fetch(api.scan.process.path, {
        method: api.scan.process.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) throw new Error("Scan processing failed");
      return api.scan.process.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      // Invalidate user queries to update balance
      queryClient.invalidateQueries({ 
        queryKey: [api.users.get.path, String(variables.userId)] 
      });
      // Invalidate activity list
      queryClient.invalidateQueries({
        queryKey: [api.activities.list.path, variables.userId]
      });
    },
  });
}
