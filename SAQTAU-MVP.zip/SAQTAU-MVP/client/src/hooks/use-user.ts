import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertUser } from "@shared/routes";
import { useLocation } from "wouter";

// Helper to store/retrieve user ID for this demo session
const STORAGE_KEY = "saqtau_user_id";

export function useCurrentUser() {
  const userId = localStorage.getItem(STORAGE_KEY);
  
  const query = useQuery({
    queryKey: [api.users.get.path, userId],
    queryFn: async () => {
      if (!userId) return null;
      const url = buildUrl(api.users.get.path, { id: userId });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch user");
      return api.users.get.responses[200].parse(await res.json());
    },
    enabled: !!userId,
  });

  return { ...query, userId };
}

export function useCreateUser() {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  return useMutation({
    mutationFn: async (data: InsertUser) => {
      const res = await fetch(api.users.create.path, {
        method: api.users.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.users.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create user");
      }
      return api.users.create.responses[201].parse(await res.json());
    },
    onSuccess: (user) => {
      localStorage.setItem(STORAGE_KEY, String(user.id));
      queryClient.setQueryData([api.users.get.path, String(user.id)], user);
      setLocation("/dashboard");
    },
  });
}

export function useLeaderboard() {
  return useQuery({
    queryKey: [api.leaderboard.list.path],
    queryFn: async () => {
      const res = await fetch(api.leaderboard.list.path);
      if (!res.ok) throw new Error("Failed to fetch leaderboard");
      return api.leaderboard.list.responses[200].parse(await res.json());
    },
  });
}
