import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

export function useActivities(userId?: number) {
  return useQuery({
    queryKey: [api.activities.list.path, userId],
    queryFn: async () => {
      if (!userId) return [];
      const url = buildUrl(api.activities.list.path, { id: userId });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch activities");
      return api.activities.list.responses[200].parse(await res.json());
    },
    enabled: !!userId,
  });
}
