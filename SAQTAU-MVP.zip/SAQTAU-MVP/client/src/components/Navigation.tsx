import { Link, useLocation } from "wouter";
import { Home, Scan, Map as MapIcon, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";

export function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { href: "/dashboard", icon: Home, label: "Home" },
    { href: "/scan", icon: Scan, label: "Scan" },
    { href: "/map", icon: MapIcon, label: "Map" },
    { href: "/leaderboard", icon: Trophy, label: "Leaders" },
  ];

  // Don't show nav on landing or onboarding
  if (location === "/" || location === "/onboarding") return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4 pb-6 bg-white/90 backdrop-blur-lg border-t border-border shadow-lg">
      <nav className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link 
              key={item.href} 
              href={item.href}
              className={cn(
                "flex flex-col items-center gap-1 p-2 rounded-2xl transition-all duration-300",
                isActive 
                  ? "text-primary bg-primary/10 -translate-y-2 scale-110 shadow-sm" 
                  : "text-muted-foreground hover:text-primary hover:bg-muted"
              )}
            >
              <item.icon className={cn("w-6 h-6", isActive && "stroke-[2.5px]")} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
