import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  district: text("district").notNull(),
  points: integer("points").default(0).notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // 'plastic', 'glass', 'wrong'
  pointsChange: integer("points_change").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'smart_bin', 'partner'
  lat: text("lat").notNull(),
  lng: text("lng").notNull(),
  address: text("address").notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, points: true, joinedAt: true });
export const insertActivitySchema = createInsertSchema(activities).omit({ id: true, timestamp: true });
export const insertLocationSchema = createInsertSchema(locations).omit({ id: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Activity = typeof activities.$inferSelect;
export type Location = typeof locations.$inferSelect;

export type ScanRequest = {
  userId: number;
  wasteType: 'plastic' | 'glass' | 'wrong';
};
