import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Create User
  app.post(api.users.create.path, async (req, res) => {
    try {
      const input = api.users.create.input.parse(req.body);
      const user = await storage.createUser(input);
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Get User
  app.get(api.users.get.path, async (req, res) => {
    const user = await storage.getUser(Number(req.params.id));
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  });

  // Scan / Process Activity
  app.post(api.scan.process.path, async (req, res) => {
    try {
      const { userId, wasteType } = api.scan.process.input.parse(req.body);
      
      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });

      let pointsChange = 0;
      let message = "";
      let success = true;

      // Logic: Wrong sorting < 3 times = explanation, else penalty
      // Count existing 'wrong' activities for this user
      const activities = await storage.getUserActivities(userId);
      const wrongCount = activities.filter(a => a.type === 'wrong').length;

      if (wasteType === 'wrong') {
        if (wrongCount < 2) { // 0, 1 -> explanation only
          pointsChange = 0;
          message = "Reminder: Please wash items before recycling!";
          success = false; // "soft" failure / warning
        } else {
          pointsChange = -5;
          message = "Penalty applied: Repeated wrong sorting.";
          success = false;
        }
      } else {
        pointsChange = 10;
        message = `Great job! Recycled ${wasteType}.`;
      }

      // Update User
      if (pointsChange !== 0) {
        await storage.updateUserPoints(userId, pointsChange);
      }

      // Log Activity
      await storage.createActivity({
        userId,
        type: wasteType,
        pointsChange
      });

      const updatedUser = await storage.getUser(userId);

      res.json({
        success,
        pointsEarned: pointsChange,
        message,
        newBalance: updatedUser?.points || 0
      });

    } catch (err) {
       res.status(400).json({ message: "Invalid request" });
    }
  });

  // Get Locations
  app.get(api.locations.list.path, async (req, res) => {
    const locs = await storage.getLocations();
    res.json(locs);
  });

  // Get User Activities
  app.get(api.activities.list.path, async (req, res) => {
    const acts = await storage.getUserActivities(Number(req.params.id));
    res.json(acts);
  });

  // Get Leaderboard
  app.get(api.leaderboard.list.path, async (req, res) => {
    const leaders = await storage.getLeaderboard();
    res.json(leaders);
  });

  return httpServer;
}
