import { users, type User, type InsertUser, type Activity, type Location } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User>;
  createActivity(activity: Omit<Activity, "id" | "timestamp">): Promise<Activity>;
  getUserActivities(userId: number): Promise<Activity[]>;
  getLocations(): Promise<Location[]>;
  getLeaderboard(): Promise<User[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private activities: Map<number, Activity>;
  private locations: Map<number, Location>;
  private currentUserId: number;
  private currentActivityId: number;
  private currentLocationId: number;

  constructor() {
    this.users = new Map();
    this.activities = new Map();
    this.locations = new Map();
    this.currentUserId = 1;
    this.currentActivityId = 1;
    this.currentLocationId = 1;

    // Seed locations
    this.seedLocations();
  }

  private seedLocations() {
    const initialLocations: Omit<Location, "id">[] = [
      { name: "Central Park Bin", type: "smart_bin", lat: "43.2389", lng: "76.8897", address: "Abay Ave" },
      { name: "Dostyk Plaza Partner", type: "partner", lat: "43.2330", lng: "76.9550", address: "Dostyk Ave" },
      { name: "Mega Center Bin", type: "smart_bin", lat: "43.2040", lng: "76.8920", address: "Rozybakiev St" },
    ];
    
    initialLocations.forEach(loc => {
      const id = this.currentLocationId++;
      this.locations.set(id, { ...loc, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      points: 0,
      joinedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPoints(userId: number, points: number): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    const updatedUser = { ...user, points: user.points + points };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async createActivity(activity: Omit<Activity, "id" | "timestamp">): Promise<Activity> {
    const id = this.currentActivityId++;
    const newActivity: Activity = { 
      ...activity, 
      id, 
      timestamp: new Date() 
    };
    this.activities.set(id, newActivity);
    return newActivity;
  }

  async getUserActivities(userId: number): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(a => a.userId === userId)
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0));
  }

  async getLocations(): Promise<Location[]> {
    return Array.from(this.locations.values());
  }

  async getLeaderboard(): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => b.points - a.points)
      .slice(0, 10);
  }
}

export const storage = new MemStorage();
